<?php
@include "includes/header.php";
?>

<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptatibus, at!</p>

<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptatibus, at!</p>
<p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Voluptatibus, at!</p>

<?php
@include "includes/footer.php";
?>