<!doctype html>
<html lang="en">

<head>
  <!-- Required meta tags -->
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <!-- Bootstrap CSS -->
  <link rel="stylesheet" href="css/bootstrap.css">
  <link rel="stylesheet" href="css/styles.css">

  <title>Südwestmetall</title>
</head>

<body>

  <header id="header">
    <div class="container">
      <div class="row">
        <div class="col-12">
          
          <nav aria-label="Login" class="d-flex justify-content-end">
            <ul>
              <li><a href="mitgliederbereich.html" title="Login">Login</a></li>
              <li><a href="sonstiges/kontakt.html" title="zum Kontaktformular">Kontakt</a></li>
            </ul>
          </nav>

          <h1 id="logo">
            <a href="index.html">
              <img src="img/logo_swm_neu.png" alt="Südwestmetall-Logo">
            </a>
          </h1>

        </div> <!-- /.col-12 -->
      </div> <!-- /.row -->

    </div> <!-- /.container -->
    
    <?php 
      @include "includes/elements/nav.php";
    ?>
    
  </header>