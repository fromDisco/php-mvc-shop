<nav class="navbar navbar-expand-lg navbar-swd" aria-label="Main Navigation">

  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbar-main" aria-controls="navbar-main" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>

  <div id="navbar-main" class="collapse navbar-collapse">
    <ul class="navbar-nav">
      <!-- M+E -->
      <li class="nav-item dropdown">
        <a href="me-industrie.html" class="nav-link dropdown-toggle" id="m-e_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">M+E-Industrie</a>
        <div class="dropdown-menu" aria-labelledby="m-e_dropdown">
            <div class="dropdown-item">
              <a href="munde-industrie/konjunktur.html">Konjunktur</a>
            </div>
            <div class="dropdown-item">
              <a href="munde-industrie/me-storys.html">M+E-Storys</a>
            </div>
        </div>
      </li>

      <!-- Südwestmetall -->
      <li class="nav-item dropdown">
        <a href="suedwestmetall.html"class="nav-link dropdown-toggle" id="swd_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Südwestmetall</a>
        <div class="dropdown-menu" aria-labelledby="swd_dropdown">
            <div class="dropdown-item">
              <a href="suedwestmetall/ueber-uns.html" target="_self">&#220;ber uns</a>
            </div>
            <div class="dropdown-item">
              <a href="suedwestmetall/bezirksgruppen.html" target="_self">Bezirksgruppen</a>
            </div>
            <div class="dropdown-item">
              <a href="suedwestmetall/struktur-gremien.html" target="_self">Struktur/Gremien</a>
            </div>
            <div class="dropdown-item">
              <a href="suedwestmetall/netzwerk.html" target="_self">Netzwerk</a></div>
            <div class="dropdown-item">
              <a href="suedwestmetall/service/veranstaltungen.html" target="_self">Veranstaltungen</a>
            </div>
        </div>
      </li>

      <!-- Südwestmetall -->
      <li class="nav-item dropdown">
        <a href="tarif.html" class="nav-link dropdown-toggle" id="tarif_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Tarif</a>
        <div class="dropdown-menu" aria-labelledby="tarif_dropdown">
            <div class="dropdown-item">
              <a href="tarif/bedeutung-von-tarifvertraegen.html" target="_self">Bedeutung von Tarifverträgen</a>
            </div>
            <div class="dropdown-item">
              <a href="tarif/tarifabschluesse/tarifabschluss-2018-in-bw.html" target="_self">Tarifabschlüsse</a>
            </div>
            <div class="dropdown-item">
              <a href="tarif/meilensteine.html" target="_self">Meilensteine</a>
            </div>
        </div>
      </li>

      <!-- Bildung -->
      <li class="nav-item dropdown">
        <a href="bildung.html" class="nav-link dropdown-toggle" id="bildung_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Bildung</a>
        <div class="dropdown-menu" aria-labelledby="bildung_dropdown">
          <div class="dropdown-item">
            <a href="bildung/vorschulische-bildung.html" target="_self">Vorschulische Bildung</a>
          </div>
          <div class="dropdown-item">
            <a href="bildung/schule.html" target="_self">Schule</a>
          </div>
          <div class="dropdown-item">
            <a href="bildung/hochschule.html" target="_self">Hochschule</a>
          </div>
          <div class="dropdown-item">
            <a href="bildung/ausbildung.html" target="_self">Ausbildung</a>
          </div>
          <div class="dropdown-item">
            <a href="bildung/weiterbildung.html" target="_self">Weiterbildung</a>
          </div>
        </div>
      </li>
      
      <!-- Arbeit und Soziales -->
      <li class="nav-item dropdown">
        <a href="arbeit-soziales.html" class="nav-link dropdown-toggle" id="arbeit-sozial_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Arbeit & Soziales</a>
        <div class="dropdown-menu" aria-labelledby="arbeit-sozial_dropdown">
          <div class="dropdown-item">
            <a href="arbeit-und-soziales/arbeitsmarktpolitik.html" target="_self">Arbeitsmarktpolitik</a>
          </div>
          <div class="dropdown-item">
            <a href="arbeit-und-soziales/soziale-sicherung.html" target="_self">Soziale Sicherung</a>
          </div>
          <div class="dropdown-item">
            <a href="arbeit-und-soziales/arbeitsrecht.html" target="_self">Arbeitsrecht</a>
          </div>
          <div class="dropdown-item">
            <a href="arbeit-und-soziales/arbeitspolitik.html" target="_self">Arbeitspolitik</a>
          </div>
        </div>
      </li>

      <!-- presse -->
      <li class="nav-item dropdown">
        <a href="presse.html" class="nav-link dropdown-toggle" id="presse_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Presse</a>
        <div class="dropdown-menu" aria-labelledby="presse_dropdown">
            <div class="dropdown-item">
              <a href="presse/pressemitteilungen.html" target="_self">Pressemitteilungen</a>
            </div>
            <div class="dropdown-item">
              <a href="presse/interviews.html" target="_self">Interviews</a>
            </div>
            <div class="dropdown-item">
              <a href="presse/viten.html" target="_self">Viten</a>
            </div>
        </div>
      </li>

      <!-- presse -->
      <li class="nav-item dropdown">
        <a href="karriere.html" class="nav-link dropdown-toggle" id="presse_dropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Karriere</a>
        <div  class="dropdown-menu" aria-labelledby="presse_dropdown">
          <div class="dropdown-item">
            <a href="karriere/karriere-bei-suedwestmetall.html" target="_self">Karriere bei S&#252;dwestmetall</a>
          </div>
          <div class="dropdown-item">
            <a href="karriere/stellenangebote.html" target="_self">Stellenangebote</a>
          </div>
          <div class="dropdown-item">
            <a href="karriere/referendariat.html" target="_self">Referendariat</a>
          </div>
          <div class="dropdown-item">
            <a href="karriere/benefits.html" target="_self">Benefits</a>
          </div>
        </div>
      </li>
    </ul>
  </div>
</nav>

